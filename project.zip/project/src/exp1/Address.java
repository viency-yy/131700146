package exp1;

//�洢��ַ��Ϣ��
public class Address {
	private String name;//����
	private String phone;//�绰
	private String province;//ʡ��
	private String city;//����
	private String region;//����
	private String town;//��
	private String detail;//����
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getProvince() {
		return province;
	}
	public void setProvince(String province) {
		this.province = province;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getDetail() {
		return detail;
	}
	public void setDetail(String detail) {
		this.detail = detail;
	}
	
	public String getTown() {
		return town;
	}
	public void setTown(String town) {
		this.town = town;
	}
	//��ӡ��Ϣ
	@Override
	public String toString() {
		return "{\"����\":\""+name+"\","+
				"\"�ֻ�\":\""+phone+"\","+
				"\"��ַ\":\"[\""+province+"\","+
				"\""+city+"\","+
				"\""+region+"\","+
				"\""+town+"\","+
				"\""+detail+"\"]}";
				
				
	}
	
	
	
	
}
